import React, { useEffect, useState } from "react";
import "./styles/App.css";
import Grid from "./components/Grid";
import Controls from "./components/Controls";
import Feedback from "./components/Feedback";
import ThemeToggle from "./components/ThemeToggle";
import { levelRules } from "./levels/levelRules";

const emptyGrid = () =>
  Array.from({ length: 5 }, () => Array.from({ length: 5 }, () => false));

const App: React.FC = () => {
  const [level, setLevel] = useState(0);
  const [pattern, setPattern] = useState(emptyGrid());
  const [flashing, setFlashing] = useState(emptyGrid());
  const [userSelection, setUserSelection] = useState(emptyGrid());
  const [revealed, setRevealed] = useState(false);
  const [phase, setPhase] = useState<"observe" | "select" | "feedback">("observe");
  const [timeLeft, setTimeLeft] = useState(10);
  const [score, setScore] = useState(0);
  const [darkMode, setDarkMode] = useState(false);
  const [started, setStarted] = useState(false); // unlock audio

  // 🎨 Theme switching
  useEffect(() => {
    document.body.dataset.theme = darkMode ? "dark" : "light";
  }, [darkMode]);

  // Unlock audio on first user interaction (Chrome restriction)
  useEffect(() => {
    const unlockAudio = () => setStarted(true);
    window.addEventListener("click", unlockAudio, { once: true });
    return () => window.removeEventListener("click", unlockAudio);
  }, []);

  // 🧠 Initialize pattern each level
  useEffect(() => {
    const rule = levelRules[level % levelRules.length].rule;
    const newPattern = Array.from({ length: 5 }, (_, r) =>
      Array.from({ length: 5 }, (_, c) => rule(r, c))
    );
    setPattern(newPattern);
    setUserSelection(emptyGrid());
    setRevealed(false);
    setPhase("observe");
    setTimeLeft(10);

    const flashInterval = setInterval(() => {
      setFlashing(
        newPattern.map((row) => row.map((cell) => (cell ? Math.random() > 0.5 : false)))
      );
    }, 400);

    const timer = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(timer);
          clearInterval(flashInterval);
          setFlashing(emptyGrid());
          setPhase("select");
          return 0;
        }
        return t - 1;
      });
    }, 1000);

    return () => {
      clearInterval(timer);
      clearInterval(flashInterval);
    };
  }, [level]);

  // 🎯 Handle square selection
  const handleSelect = (r: number, c: number) => {
    if (phase !== "select") return;
    const updated = userSelection.map((row, ri) =>
      row.map((cell, ci) => (ri === r && ci === c ? !cell : cell))
    );
    setUserSelection(updated);
  };

  // 🔊 Helper function for generating tones
  const playTone = (frequency: number, duration: number) => {
    if (!started) return;
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g);
    g.connect(ctx.destination);
    o.type = "sine";
    o.frequency.value = frequency;
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    o.stop(ctx.currentTime + duration);
  };

  // ✅ Submit answer and check accuracy
  const handleSubmit = () => {
    setRevealed(true);
    setPhase("feedback");

    let correct = 0;
    let totalCorrect = 0;
    let totalSelected = 0;

    pattern.forEach((row, r) =>
      row.forEach((cell, c) => {
        if (cell) totalCorrect++;
        if (userSelection[r][c]) totalSelected++;
        if (cell && userSelection[r][c]) correct++;
      })
    );

    const accuracy = totalSelected > 0 ? Math.round((correct / totalSelected) * 100) : 0;
    setScore((prev) => prev + correct);

    // 🔊 Play success or error tone
    if (accuracy >= 70) {
      playTone(600, 0.3); // ✅ success tone
    } else {
      playTone(200, 0.3); // ❌ error tone
    }
  };

  // ➡️ Go to next level
  const nextLevel = () => {
    setLevel((prev) => prev + 1);
    playTone(700, 0.2); // 🎵 short level-up tone
  };

  return (
    <div className="app">
      <ThemeToggle darkMode={darkMode} setDarkMode={setDarkMode} />

      <div className="game-container">
        <h1>🧠 Pattern Decoder Game</h1>
        <h2>
          Level {level + 1}: {levelRules[level % levelRules.length].name}
        </h2>

        {phase === "observe" && <p className="timer">⏱ Observe: {timeLeft}s</p>}
        <p className="score">⭐ Score: {score}</p>

        <Grid
          pattern={pattern}
          flashing={flashing}
          revealed={revealed}
          userSelection={userSelection}
          onSelect={handleSelect}
        />

        <Controls phase={phase} onSubmit={handleSubmit} onNext={nextLevel} />

        {phase === "feedback" && (
          <Feedback pattern={pattern} userSelection={userSelection} />
        )}
      </div>
    </div>
  );
};

export default App;
