export const levelRules = [
  { name: "Even indices", rule: (r: number, c: number) => (r + c) % 2 === 0 },
  { name: "Diagonal", rule: (r: number, c: number) => r === c || r + c === 4 },
  { name: "Prime indices", rule: (r: number, c: number) => [2, 3].includes(r) || [2, 3].includes(c) },
  { name: "Center cluster", rule: (r: number, c: number) => r >= 1 && r <= 3 && c >= 1 && c <= 3 },
  { name: "(r + c) % 3 === 0", rule: (r: number, c: number) => (r + c) % 3 === 0 },
];
