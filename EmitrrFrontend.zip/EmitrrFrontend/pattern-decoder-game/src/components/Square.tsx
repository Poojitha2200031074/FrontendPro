import React from "react";

interface SquareProps {
  flashing: boolean;
  selected: boolean;
  revealed: boolean;
  correct: boolean;
  onClick: () => void;
}

const Square: React.FC<SquareProps> = ({
  flashing,
  selected,
  revealed,
  correct,
  onClick,
}) => {
  let className = "square";

  if (revealed) {
    if (correct && selected) className += " correct tick"; // ✅ Correct selection
    else if (!correct && selected) className += " incorrect cross"; // ❌ Wrong selection
    else if (correct && !selected) className += " correct tick"; // ✅ Missed correct
  } else {
    if (flashing) className += " flashing";
    if (selected) className += " selected";
  }

  return <div className={className} onClick={onClick}></div>;
};

export default Square;
