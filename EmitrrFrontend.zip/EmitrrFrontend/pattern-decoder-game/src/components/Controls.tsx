import React from "react";

interface ControlsProps {
  phase: "observe" | "select" | "feedback";
  onSubmit: () => void;
  onNext: () => void;
}

const Controls: React.FC<ControlsProps> = ({ phase, onSubmit, onNext }) => {
  return (
    <div>
      {phase === "select" && (
        <button className="btn" onClick={onSubmit}>
          Submit
        </button>
      )}
      {phase === "feedback" && (
        <button className="btn" onClick={onNext}>
          Next Level
        </button>
      )}
    </div>
  );
};

export default Controls;
