import React from "react";

interface ThemeToggleProps {
  darkMode: boolean;
  setDarkMode: React.Dispatch<React.SetStateAction<boolean>>;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ darkMode, setDarkMode }) => (
  <button className="theme-btn" onClick={() => setDarkMode(!darkMode)}>
    {darkMode ? "🌞 Light Mode" : "🌙 Dark Mode"}
  </button>
);

export default ThemeToggle;
