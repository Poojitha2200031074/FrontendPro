import React from "react";

interface FeedbackProps {
  pattern: boolean[][];
  userSelection: boolean[][];
}

const Feedback: React.FC<FeedbackProps> = ({ pattern, userSelection }) => {
  const totalCorrect = pattern.flat().filter(Boolean).length;
  const totalSelected = userSelection.flat().filter(Boolean).length;

  const matched = pattern
    .flatMap((row, r) => row.map((cell, c) => cell && userSelection[r][c]))
    .filter(Boolean).length;

  const accuracy =
    totalSelected > 0 ? Math.round((matched / totalSelected) * 100) : 0;

  let message = "";
  if (accuracy === 100 && matched === totalCorrect) {
    message = "🏆 Perfect! You decoded the pattern flawlessly!";
  } else if (accuracy >= 70) {
    message = "🎯 Great job! You're very close to perfect!";
  } else if (accuracy > 0) {
    message = "💡 Not bad — observe carefully next round!";
  } else {
    message = "❌ Oops! Try to notice the flashing pattern more closely.";
  }

  return (
    <div className="feedback">
      <h3>📊 Round Results</h3>

      <div className="feedback-grid">
        <p>✅ <strong>Correct Squares:</strong> {totalCorrect}</p>
        <p>🖱 <strong>Your Selections:</strong> {totalSelected}</p>
        <p>🎯 <strong>Matches:</strong> {matched}</p>
        <p>📈 <strong>Accuracy:</strong> {accuracy}%</p>
      </div>

      <div
        className="feedback-message"
        style={{
          marginTop: "10px",
          fontWeight: "bold",
          color:
            accuracy === 100
              ? "#2e7d32"
              : accuracy >= 70
              ? "#388e3c"
              : accuracy > 0
              ? "#f57c00"
              : "#d32f2f",
        }}
      >
        {message}
      </div>
    </div>
  );
};

export default Feedback;
