import React from "react";
import Square from "./Square";

interface GridProps {
  pattern: boolean[][];
  flashing: boolean[][];
  revealed: boolean;
  userSelection: boolean[][];
  onSelect: (r: number, c: number) => void;
}

const Grid: React.FC<GridProps> = ({
  pattern,
  flashing,
  revealed,
  userSelection,
  onSelect,
}) => (
  <div className="grid">
    {pattern.map((row, r) =>
      row.map((_, c) => {
        const flash = flashing?.[r]?.[c];
        const selected = userSelection?.[r]?.[c];
        const correct = revealed && pattern?.[r]?.[c];
       
        return (
          <Square
            key={`${r}-${c}`}
            flashing={!!flash}
            selected={!!selected}
            revealed={revealed}
            correct={!!correct}
           
            onClick={() => onSelect(r, c)}
          />
        );
      })
    )}
  </div>
);

export default Grid;
