🧠 Pattern Decoder Game

A fun and interactive memory challenge game built with **React + Vite + TypeScript**.  
Players watch flashing patterns on a 5x5 grid, try to remember them, and then select which squares flashed.  
Each level introduces a hidden mathematical or visual pattern, testing both memory and pattern recognition.
Includes multiple levels, scoring, timer, feedback animations, and light/dark mode.



🚀 Features

✅ Dynamic 5x5 grid with level-based flashing rules
⏱️ Observation timer before user input phase
⭐ Score counter to track performance across levels
💡 Visual feedback — ✅ Tick marks for correct, ❌ Cross marks for incorrect
🎞️ CSS-animations for smooth transitions
🌗 Light/Dark mode toggle
🔊 Optional sound feedback for correct & incorrect answers
🧩 Expandable pattern system (levels/levelRules.ts) for easy customization


🧠 Game Rules / How It Works

Observe a 5x5 grid of flashing squares for 10 seconds.

The flashing follows a hidden rule (e.g., even indices, diagonals, primes, etc.).

Once the flashing stops, select the squares you think were flashing.

Hit Submit to get feedback:

✅ Correct squares

❌ Incorrect selections

View your accuracy, update your score, and progress to the next level!

